
package nopurpose;

import java.util.Scanner;

public class NoPurpose {

    
    
    
    public static void main(String[] args) {
        
        /*this creates a scanner object*/
        Scanner choice = new Scanner(System.in);
        
        /*this will be the variable used for user input*/
        int userchoice;
        
        System.out.println("********CHOOSE OPTION********");
        System.out.println("Default Option - Press 1");
        System.out.println("Custom Option - Press 2");
        
        System.out.print("Your Choice Here:");
        /*this is where the user selects the default or custom menu */
        userchoice = choice.nextInt();
        
        /*this code will execute if user chooses "1"(Default menu)*/
        if (userchoice == 1){
            
            /*this creates the object for a default menu (from the Default class*/
            Default dm = new Default();
            
            /*this calls the defaultmenu method from the Default class*/
            dm.defaultmenu();
            
            
        }
        
        /*this code will execute if user chooses "2"(Custom menu)*/
        else if (userchoice == 2){
                    
                    Custom cm = new Custom();
                    
                    cm.custommenu();
                    
                    }
        
        /*this code will execute if user does not enter a valid option ("1" or "2")*/
        else {
            System.out.println("not valid");
        }
        
    }
    
}
