
package nopurpose;

import java.util.Scanner;

public class Custom {
    
    
    /*this is the constructor*/
    public Custom(){
        
    }
    
    public static void custommenu(){
        
        int dal;
        int roti;
        int subjione;
        int subjitwo;
        int kheer;
        
        Scanner written = new Scanner(System.in);
        
        System.out.println("Build Your Plate: Enter Item Amount (in Scoops) ");
        
        System.out.println("Dal:");
        dal = written.nextInt();
        
        System.out.println("Roti:");
        roti = written.nextInt();
        
        System.out.println("Subji One:");
        subjione = written.nextInt();
        
        System.out.println("Subji Two:");
        subjitwo = written.nextInt();
        
        System.out.println("Kheer:");
        kheer = written.nextInt();
        
        System.out.println("Your Plate -" + " " + "DAL: " + dal + ", " + "ROTI: " + roti + ", " + "SUBJI ONE: " + subjione + ", " + "SUBJI TWO: " + subjitwo + ", " + "KHEER: " + kheer);
        
    }
    
}
