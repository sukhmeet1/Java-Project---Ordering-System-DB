
package nopurpose;

import java.util.Scanner;

public class Default {
    
    /*this is the constructor*/
    public Default(){
        
    }
    
    public static void defaultmenu(){
        
        int defchoice;
        
        Scanner thepen = new Scanner(System.in);
        
        System.out.println("Choose Your Plate");
        System.out.println("Plate 1: Everything");
        System.out.println("Plate 2: 2 Roti, Full Dal,Full Kheer");
        System.out.println("Plate 3: 1 Roti, 1/2 Dal, 1/2 Kheer");
        System.out.println("Plate 4: 1 Roti, Full Dal, Full Subji One, Full Subji Two");
        
        System.out.print("Your Choice:");
        
        defchoice = thepen.nextInt();
        
        if (defchoice == 1){
            
            System.out.println("You chose Plate 1");
            
        }
        
        else if (defchoice == 2){
            
            System.out.println("You chose Plate 2");
            
        }
        
        else if (defchoice == 3){
            
            System.out.println("You chose Plate 3");
            
        }
        
        else if (defchoice == 4){
            
            System.out.println("You chose Plate 4");
            
        }
        
        else {
            System.out.println("Not a Valid Choice");
        }
        
    }
    
    
}
